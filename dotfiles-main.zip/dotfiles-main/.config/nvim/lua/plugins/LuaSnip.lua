return {
  "L3MON4D3/LuaSnip",
  keys = function()
    return {}
  end,
}
