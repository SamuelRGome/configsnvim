return {
  "norcalli/nvim-colorizer.lua",
  opts = {
    "css",
    "scss",
    "sass",
    "javascript",
    "html",
    "pug",
  },
}
